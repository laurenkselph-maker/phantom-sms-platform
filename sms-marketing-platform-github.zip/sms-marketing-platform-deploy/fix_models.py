#!/usr/bin/env python3
"""
Fix all SQLAlchemy relationship issues in models
"""
import os
import re

def fix_model_file(filepath):
    """Remove problematic relationships from a model file"""
    with open(filepath, 'r') as f:
        content = f.read()
    
    # Remove relationship lines
    lines = content.split('\n')
    new_lines = []
    skip_next = False
    
    for line in lines:
        # Skip relationship definitions
        if 'db.relationship' in line or 'backref=' in line:
            continue
        # Skip lines that are part of relationship definitions
        if skip_next and (line.strip().startswith('backref=') or line.strip().startswith('cascade=')):
            continue
        skip_next = False
        
        # Fix imports to use relative import from __init__
        if line.strip().startswith('from .user import db'):
            line = 'from . import db'
        elif line.strip().startswith('from .org import db'):
            line = 'from . import db'
        elif line.strip().startswith('from .lead_list import db'):
            line = 'from . import db'
            
        new_lines.append(line)
    
    # Write back the fixed content
    with open(filepath, 'w') as f:
        f.write('\n'.join(new_lines))
    
    print(f"Fixed: {filepath}")

def main():
    models_dir = "/home/ubuntu/sms-marketing-app/src/models"
    
    # List of model files to fix
    model_files = [
        'analytics_daily.py',
        'campaign.py', 
        'conversation.py',
        'integration.py',
        'lead.py',
        'meeting_event.py',
        'message.py',
        'sending_number.py'
    ]
    
    for model_file in model_files:
        filepath = os.path.join(models_dir, model_file)
        if os.path.exists(filepath):
            fix_model_file(filepath)
    
    print("All model files fixed!")

if __name__ == "__main__":
    main()

