#!/usr/bin/env python3
"""
Simple user creation script for SMS Marketing Platform
"""
import os
import sys
import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime

def create_user_account():
    """Create a user account directly in the database"""
    db_path = "/home/ubuntu/sms-marketing-app/src/database/app.db"
    
    # Ensure database directory exists
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create tables if they don't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS orgs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(100) NOT NULL,
            billing_info TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(120) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'agent',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1,
            FOREIGN KEY (org_id) REFERENCES orgs (id)
        )
    ''')
    
    # Create organization
    cursor.execute('''
        INSERT OR REPLACE INTO orgs (name, created_at, is_active)
        VALUES (?, ?, ?)
    ''', ("Demo Organization", datetime.utcnow().isoformat(), 1))
    
    org_id = cursor.lastrowid
    
    # Create user
    password_hash = generate_password_hash("demo123")
    cursor.execute('''
        INSERT OR REPLACE INTO users (org_id, name, email, password_hash, role, created_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (org_id, "Demo User", "demo@example.com", password_hash, "owner", datetime.utcnow().isoformat(), 1))
    
    conn.commit()
    conn.close()
    
    print("✅ User account created successfully!")
    print("📧 Email: demo@example.com")
    print("🔑 Password: demo123")
    print("🏢 Organization: Demo Organization")
    print("🎯 Role: Owner")

if __name__ == "__main__":
    create_user_account()

