#!/usr/bin/env python3
"""
Database initialization script for SMS Marketing Platform
"""
import os
import sys
from datetime import datetime

# Add the project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.main import create_app
from src.models import db
from src.models.user import User
from src.models.org import Org
from werkzeug.security import generate_password_hash

def init_database():
    """Initialize the database and create tables"""
    app = create_app()
    
    with app.app_context():
        # Drop all tables and recreate them
        db.drop_all()
        db.create_all()
        
        print("Database tables created successfully!")
        
        # Create a test user account
        test_org = Org(
            name="Demo Organization",
            created_at=datetime.utcnow()
        )
        db.session.add(test_org)
        db.session.flush()  # Get the org ID
        
        test_user = User(
            name="Demo User",
            email="demo@example.com",
            password_hash=generate_password_hash("demo123"),
            org_id=test_org.id,
            created_at=datetime.utcnow()
        )
        db.session.add(test_user)
        db.session.commit()
        
        print("Test user created:")
        print("Email: demo@example.com")
        print("Password: demo123")
        print("Organization: Demo Organization")

if __name__ == "__main__":
    init_database()

