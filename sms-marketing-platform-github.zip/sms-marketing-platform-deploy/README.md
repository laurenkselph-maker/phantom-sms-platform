# SMS Marketing Platform

A complete SMS marketing application with lead management, campaign creation, and analytics dashboard.

## 🚀 One-Click Deploy to Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/sms-marketing-platform)

## Features

- **Lead Management**: Upload CSV files or purchase targeted leads
- **Phone Number Management**: Purchase and manage sending numbers (200 messages/day per number)
- **SMS Campaigns**: Create campaigns with AI-generated message variants
- **Analytics Dashboard**: Track outbound sent, inbound received, meetings booked
- **Integrations**: Ready for Make.com and n8n automation
- **Clean Design**: Minimalistic and professional interface

## Quick Start

1. Click the "Deploy on Railway" button above
2. Connect your GitHub account
3. Railway will automatically deploy your application
4. Get your live URL and start using the platform

## Default Login

After deployment, you can login with:
- **Email**: demo@example.com
- **Password**: demo123

## Admin Features

- User management
- Campaign templates
- Integration settings
- Analytics configuration
- Branding customization

## Tech Stack

- **Backend**: Flask (Python)
- **Frontend**: React
- **Database**: SQLite (upgradeable to PostgreSQL)
- **Hosting**: Railway (recommended)

## Support

For questions or support, contact your development team.

## License

Proprietary - All rights reserved

