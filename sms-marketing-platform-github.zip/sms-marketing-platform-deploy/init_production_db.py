#!/usr/bin/env python3
"""
Production database initialization script for SMS Marketing Platform
"""
import os
import sqlite3
from werkzeug.security import generate_password_hash
from datetime import datetime

def setup_database():
    """Initialize database with proper schema and sample data"""
    db_path = os.path.join(os.path.dirname(__file__), 'src', 'database', 'app.db')
    
    # Ensure database directory exists
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    # Connect to database
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create all tables with proper schema
    cursor.executescript('''
        -- Organizations table
        CREATE TABLE IF NOT EXISTS orgs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(100) NOT NULL,
            billing_info TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1
        );
        
        -- Users table
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(120) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(20) DEFAULT 'owner',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            is_active BOOLEAN DEFAULT 1,
            FOREIGN KEY (org_id) REFERENCES orgs (id)
        );
        
        -- Lead lists table
        CREATE TABLE IF NOT EXISTS lead_lists (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            name VARCHAR(100) NOT NULL,
            status VARCHAR(20) DEFAULT 'ready',
            source VARCHAR(20) NOT NULL,
            tam_criteria TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (org_id) REFERENCES orgs (id)
        );
        
        -- Leads table
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lead_list_id INTEGER NOT NULL,
            name VARCHAR(100),
            email VARCHAR(120),
            phone VARCHAR(20) NOT NULL,
            company VARCHAR(100),
            title VARCHAR(100),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (lead_list_id) REFERENCES lead_lists (id)
        );
        
        -- Sending numbers table
        CREATE TABLE IF NOT EXISTS sending_numbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            phone_number VARCHAR(20) NOT NULL,
            daily_limit INTEGER DEFAULT 200,
            daily_sent INTEGER DEFAULT 0,
            last_reset_date DATE,
            status VARCHAR(20) DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (org_id) REFERENCES orgs (id)
        );
        
        -- Campaigns table
        CREATE TABLE IF NOT EXISTS campaigns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            name VARCHAR(100) NOT NULL,
            base_message TEXT NOT NULL,
            lead_list_id INTEGER NOT NULL,
            sending_number_id INTEGER NOT NULL,
            status VARCHAR(20) DEFAULT 'draft',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (org_id) REFERENCES orgs (id),
            FOREIGN KEY (lead_list_id) REFERENCES lead_lists (id),
            FOREIGN KEY (sending_number_id) REFERENCES sending_numbers (id)
        );
        
        -- Conversations table
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            lead_id INTEGER NOT NULL,
            sending_number_id INTEGER NOT NULL,
            status VARCHAR(20) DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (org_id) REFERENCES orgs (id),
            FOREIGN KEY (lead_id) REFERENCES leads (id),
            FOREIGN KEY (sending_number_id) REFERENCES sending_numbers (id)
        );
        
        -- Messages table
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            conversation_id INTEGER NOT NULL,
            content TEXT NOT NULL,
            direction VARCHAR(10) NOT NULL,
            sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (conversation_id) REFERENCES conversations (id)
        );
        
        -- Meeting events table
        CREATE TABLE IF NOT EXISTS meeting_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            lead_id INTEGER NOT NULL,
            conversation_id INTEGER,
            meeting_date DATETIME,
            status VARCHAR(20) DEFAULT 'scheduled',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (org_id) REFERENCES orgs (id),
            FOREIGN KEY (lead_id) REFERENCES leads (id),
            FOREIGN KEY (conversation_id) REFERENCES conversations (id)
        );
        
        -- Analytics daily table
        CREATE TABLE IF NOT EXISTS analytics_daily (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            date DATE NOT NULL,
            outbound_sent INTEGER DEFAULT 0,
            inbound_received INTEGER DEFAULT 0,
            meetings_booked INTEGER DEFAULT 0,
            FOREIGN KEY (org_id) REFERENCES orgs (id)
        );
        
        -- Integrations table
        CREATE TABLE IF NOT EXISTS integrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            org_id INTEGER NOT NULL,
            name VARCHAR(50) NOT NULL,
            type VARCHAR(20) NOT NULL,
            config TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (org_id) REFERENCES orgs (id)
        );
    ''')
    
    print("✅ Database tables created successfully!")
    
    # Create sample organization and user
    cursor.execute('''
        INSERT OR IGNORE INTO orgs (name, created_at, is_active)
        VALUES (?, ?, ?)
    ''', ("Demo Organization", datetime.utcnow().isoformat(), 1))
    
    org_id = cursor.lastrowid or 1
    
    # Create sample user
    password_hash = generate_password_hash("demo123")
    cursor.execute('''
        INSERT OR IGNORE INTO users (org_id, name, email, password_hash, role, created_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (org_id, "Demo User", "demo@example.com", password_hash, "owner", datetime.utcnow().isoformat(), 1))
    
    # Create sample data for demonstration
    cursor.execute('''
        INSERT OR IGNORE INTO lead_lists (org_id, name, status, source, created_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (org_id, "Sample Lead List", "ready", "upload", datetime.utcnow().isoformat()))
    
    list_id = cursor.lastrowid or 1
    
    # Add sample leads
    sample_leads = [
        ("John Smith", "john@example.com", "+1234567890", "Acme Corp", "CEO"),
        ("Jane Doe", "jane@example.com", "+1234567891", "Tech Inc", "CTO"),
        ("Bob Johnson", "bob@example.com", "+1234567892", "Sales Co", "VP Sales")
    ]
    
    for lead in sample_leads:
        cursor.execute('''
            INSERT OR IGNORE INTO leads (lead_list_id, name, email, phone, company, title, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (list_id, *lead, datetime.utcnow().isoformat()))
    
    # Add sample sending number
    cursor.execute('''
        INSERT OR IGNORE INTO sending_numbers (org_id, phone_number, daily_limit, daily_sent, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (org_id, "+1555123456", 200, 0, "active", datetime.utcnow().isoformat()))
    
    # Add sample analytics data
    cursor.execute('''
        INSERT OR IGNORE INTO analytics_daily (org_id, date, outbound_sent, inbound_received, meetings_booked)
        VALUES (?, ?, ?, ?, ?)
    ''', (org_id, datetime.utcnow().date().isoformat(), 150, 45, 12))
    
    conn.commit()
    conn.close()
    
    print("✅ Sample data created successfully!")
    print("📧 Demo Login: demo@example.com")
    print("🔑 Demo Password: demo123")
    print("🏢 Organization: Demo Organization")

if __name__ == "__main__":
    setup_database()
