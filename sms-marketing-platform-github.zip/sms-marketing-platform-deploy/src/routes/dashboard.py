from flask import Blueprint, request, jsonify
from src.models import db
from src.models.message import Message
from src.models.meeting_event import MeetingEvent
from src.models.analytics_daily import AnalyticsDaily
from src.routes.auth import require_auth
from datetime import datetime, date, timedelta
from sqlalchemy import func

dashboard_bp = Blueprint('dashboard', __name__)

@dashboard_bp.route('/summary', methods=['GET'])
def get_dashboard_summary():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Get date range parameters
        from_date = request.args.get('from')
        to_date = request.args.get('to')
        
        # Parse dates or use defaults
        if from_date:
            try:
                from_date = datetime.fromisoformat(from_date).date()
            except ValueError:
                return jsonify({'error': 'Invalid from date format'}), 400
        
        if to_date:
            try:
                to_date = datetime.fromisoformat(to_date).date()
            except ValueError:
                return jsonify({'error': 'Invalid to date format'}), 400
        
        # Handle preset ranges
        range_type = request.args.get('range', 'all_time')
        today = date.today()
        
        if range_type == 'today':
            from_date = to_date = today
        elif range_type == 'last_7_days':
            from_date = today - timedelta(days=7)
            to_date = today
        elif range_type == 'last_30_days':
            from_date = today - timedelta(days=30)
            to_date = today
        elif range_type == 'last_90_days':
            from_date = today - timedelta(days=90)
            to_date = today
        elif range_type == 'last_180_days':
            from_date = today - timedelta(days=180)
            to_date = today
        elif range_type == 'all_time':
            from_date = None
            to_date = None
        
        # Build base queries
        message_query = Message.query.join(Message.conversation).filter(
            Message.conversation.has(org_id=user.org_id)
        )
        
        meeting_query = MeetingEvent.query.filter_by(org_id=user.org_id)
        
        # Apply date filters
        if from_date:
            message_query = message_query.filter(func.date(Message.created_at) >= from_date)
            meeting_query = meeting_query.filter(func.date(MeetingEvent.created_at) >= from_date)
        
        if to_date:
            message_query = message_query.filter(func.date(Message.created_at) <= to_date)
            meeting_query = meeting_query.filter(func.date(MeetingEvent.created_at) <= to_date)
        
        # Calculate KPIs
        total_outbound = message_query.filter_by(direction='outbound').count()
        total_inbound = message_query.filter_by(direction='inbound').count()
        total_meetings = meeting_query.count()
        
        # Get meeting links sent from analytics
        analytics_query = AnalyticsDaily.query.filter_by(org_id=user.org_id)
        if from_date:
            analytics_query = analytics_query.filter(AnalyticsDaily.date >= from_date)
        if to_date:
            analytics_query = analytics_query.filter(AnalyticsDaily.date <= to_date)
        
        total_meeting_links = sum(a.meeting_links_sent for a in analytics_query.all())
        
        return jsonify({
            'summary': {
                'total_outbound_sent': total_outbound,
                'total_inbound_received': total_inbound,
                'meetings_booked': total_meetings,
                'meeting_links_sent': total_meeting_links
            },
            'date_range': {
                'from': from_date.isoformat() if from_date else None,
                'to': to_date.isoformat() if to_date else None,
                'range_type': range_type
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/timeseries', methods=['GET'])
def get_timeseries_data():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Get parameters
        metric = request.args.get('metric', 'outbound')  # outbound, inbound, meetings, meeting_links_sent
        from_date = request.args.get('from')
        to_date = request.args.get('to')
        range_type = request.args.get('range', 'last_30_days')
        
        # Parse dates
        today = date.today()
        
        if range_type == 'today':
            from_date = to_date = today
        elif range_type == 'last_7_days':
            from_date = today - timedelta(days=7)
            to_date = today
        elif range_type == 'last_30_days':
            from_date = today - timedelta(days=30)
            to_date = today
        elif range_type == 'last_90_days':
            from_date = today - timedelta(days=90)
            to_date = today
        elif range_type == 'last_180_days':
            from_date = today - timedelta(days=180)
            to_date = today
        else:
            # Custom range
            if from_date:
                from_date = datetime.fromisoformat(from_date).date()
            else:
                from_date = today - timedelta(days=30)
            
            if to_date:
                to_date = datetime.fromisoformat(to_date).date()
            else:
                to_date = today
        
        # Generate date range
        date_range = []
        current_date = from_date
        while current_date <= to_date:
            date_range.append(current_date)
            current_date += timedelta(days=1)
        
        # Get data based on metric
        timeseries_data = []
        
        if metric in ['outbound', 'inbound']:
            # Get message data
            for target_date in date_range:
                count = Message.query.join(Message.conversation).filter(
                    Message.conversation.has(org_id=user.org_id),
                    Message.direction == metric,
                    func.date(Message.created_at) == target_date
                ).count()
                
                timeseries_data.append({
                    'date': target_date.isoformat(),
                    'value': count
                })
        
        elif metric == 'meetings':
            # Get meeting data
            for target_date in date_range:
                count = MeetingEvent.query.filter(
                    MeetingEvent.org_id == user.org_id,
                    func.date(MeetingEvent.created_at) == target_date
                ).count()
                
                timeseries_data.append({
                    'date': target_date.isoformat(),
                    'value': count
                })
        
        elif metric == 'meeting_links_sent':
            # Get meeting links data from analytics
            for target_date in date_range:
                analytics = AnalyticsDaily.query.filter_by(
                    org_id=user.org_id,
                    date=target_date
                ).first()
                
                count = analytics.meeting_links_sent if analytics else 0
                
                timeseries_data.append({
                    'date': target_date.isoformat(),
                    'value': count
                })
        
        return jsonify({
            'timeseries': timeseries_data,
            'metric': metric,
            'date_range': {
                'from': from_date.isoformat(),
                'to': to_date.isoformat(),
                'range_type': range_type
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/recent-activity', methods=['GET'])
def get_recent_activity():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        limit = request.args.get('limit', 10, type=int)
        
        # Get recent messages
        recent_messages = Message.query.join(Message.conversation).filter(
            Message.conversation.has(org_id=user.org_id)
        ).order_by(Message.created_at.desc()).limit(limit).all()
        
        # Get recent meetings
        recent_meetings = MeetingEvent.query.filter_by(
            org_id=user.org_id
        ).order_by(MeetingEvent.created_at.desc()).limit(limit).all()
        
        # Combine and sort by timestamp
        activity = []
        
        for msg in recent_messages:
            activity.append({
                'type': 'message',
                'timestamp': msg.created_at.isoformat(),
                'data': msg.to_dict()
            })
        
        for meeting in recent_meetings:
            activity.append({
                'type': 'meeting',
                'timestamp': meeting.created_at.isoformat(),
                'data': meeting.to_dict()
            })
        
        # Sort by timestamp (newest first)
        activity.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return jsonify({
            'recent_activity': activity[:limit]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@dashboard_bp.route('/numbers-usage', methods=['GET'])
def get_numbers_usage():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        from src.models.sending_number import SendingNumber
        
        numbers = SendingNumber.query.filter_by(org_id=user.org_id).all()
        
        usage_data = []
        for number in numbers:
            usage_data.append({
                'number': number.to_dict(),
                'usage_today': number.daily_sent_count,
                'remaining_today': number.remaining_today,
                'usage_percentage': (number.daily_sent_count / number.daily_cap) * 100 if number.daily_cap > 0 else 0
            })
        
        return jsonify({
            'numbers_usage': usage_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

