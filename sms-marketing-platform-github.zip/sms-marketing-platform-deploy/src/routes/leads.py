from flask import Blueprint, request, jsonify, session
from src.models import db
from src.models.lead_list import LeadList
from src.models.lead import Lead
from src.routes.auth import require_auth
import csv
import io
import re
import json

leads_bp = Blueprint('leads', __name__)

def validate_phone_e164(phone):
    """Validate phone number in E.164 format"""
    pattern = r'^\+[1-9]\d{1,14}$'
    return re.match(pattern, phone) is not None

def normalize_phone(phone):
    """Normalize phone number to E.164 format"""
    # Remove all non-digit characters except +
    cleaned = re.sub(r'[^\d+]', '', phone)
    
    # If it doesn't start with +, assume US number and add +1
    if not cleaned.startswith('+'):
        if len(cleaned) == 10:
            cleaned = '+1' + cleaned
        elif len(cleaned) == 11 and cleaned.startswith('1'):
            cleaned = '+' + cleaned
        else:
            cleaned = '+1' + cleaned
    
    return cleaned

@leads_bp.route('/upload', methods=['POST'])
def upload_leads():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Check if file is present
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Get list name
        list_name = request.form.get('name')
        if not list_name:
            return jsonify({'error': 'List name is required'}), 400
        
        # Read CSV file
        try:
            content = file.read().decode('utf-8')
            csv_reader = csv.DictReader(io.StringIO(content))
        except Exception as e:
            return jsonify({'error': 'Invalid CSV file format'}), 400
        
        # Create lead list
        lead_list = LeadList(
            org_id=user.org_id,
            name=list_name,
            source='upload',
            status='ready'
        )
        db.session.add(lead_list)
        db.session.flush()
        
        # Process leads
        leads_created = 0
        invalid_phones = []
        
        for row_num, row in enumerate(csv_reader, start=2):
            # Extract phone number (try different column names)
            phone = row.get('phone') or row.get('Phone') or row.get('PHONE') or row.get('phone_number')
            if not phone:
                continue
            
            # Normalize and validate phone
            normalized_phone = normalize_phone(phone)
            is_valid = validate_phone_e164(normalized_phone)
            
            if not is_valid:
                invalid_phones.append({'row': row_num, 'phone': phone})
            
            # Create lead
            lead = Lead(
                lead_list_id=lead_list.id,
                name=row.get('name') or row.get('Name') or row.get('NAME'),
                phone=normalized_phone,
                email=row.get('email') or row.get('Email') or row.get('EMAIL'),
                title=row.get('title') or row.get('Title') or row.get('TITLE'),
                company=row.get('company') or row.get('Company') or row.get('COMPANY'),
                industry=row.get('industry') or row.get('Industry') or row.get('INDUSTRY'),
                location=row.get('location') or row.get('Location') or row.get('LOCATION'),
                notes=row.get('notes') or row.get('Notes') or row.get('NOTES'),
                valid=is_valid
            )
            db.session.add(lead)
            leads_created += 1
        
        db.session.commit()
        
        return jsonify({
            'message': f'Successfully uploaded {leads_created} leads',
            'lead_list': lead_list.to_dict(),
            'invalid_phones': invalid_phones
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/purchase', methods=['POST'])
def purchase_leads():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'title', 'company_type', 'location']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Create lead list with sourcing status
        lead_list = LeadList(
            org_id=user.org_id,
            name=data['name'],
            source='purchase',
            status='sourcing',
            tam_criteria=json.dumps({
                'title': data['title'],
                'company_type': data['company_type'],
                'industry': data.get('industry'),
                'location': data['location'],
                'company_size': data.get('company_size'),
                'additional_criteria': data.get('additional_criteria')
            })
        )
        db.session.add(lead_list)
        db.session.commit()
        
        return jsonify({
            'message': 'Lead purchase request submitted. Processing will take 3-5 days.',
            'lead_list': lead_list.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/lists', methods=['GET'])
def get_lead_lists():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        lead_lists = LeadList.query.filter_by(org_id=user.org_id).order_by(LeadList.created_at.desc()).all()
        
        return jsonify({
            'lead_lists': [ll.to_dict() for ll in lead_lists]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/lists/<int:list_id>', methods=['GET'])
def get_lead_list(list_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        lead_list = LeadList.query.filter_by(id=list_id, org_id=user.org_id).first()
        if not lead_list:
            return jsonify({'error': 'Lead list not found'}), 404
        
        return jsonify({
            'lead_list': lead_list.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/lists/<int:list_id>/leads', methods=['GET'])
def get_leads_in_list(list_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Verify list belongs to user's org
        lead_list = LeadList.query.filter_by(id=list_id, org_id=user.org_id).first()
        if not lead_list:
            return jsonify({'error': 'Lead list not found'}), 404
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        # Get leads with pagination
        leads_query = Lead.query.filter_by(lead_list_id=list_id)
        leads_paginated = leads_query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'leads': [lead.to_dict() for lead in leads_paginated.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': leads_paginated.total,
                'pages': leads_paginated.pages,
                'has_next': leads_paginated.has_next,
                'has_prev': leads_paginated.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@leads_bp.route('/lists/<int:list_id>', methods=['DELETE'])
def delete_lead_list(list_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        lead_list = LeadList.query.filter_by(id=list_id, org_id=user.org_id).first()
        if not lead_list:
            return jsonify({'error': 'Lead list not found'}), 404
        
        # Check if list is being used in any campaigns
        from src.models.campaign import Campaign
        campaigns_using_list = Campaign.query.filter_by(lead_list_id=list_id).count()
        if campaigns_using_list > 0:
            return jsonify({'error': 'Cannot delete list that is being used in campaigns'}), 400
        
        db.session.delete(lead_list)
        db.session.commit()
        
        return jsonify({'message': 'Lead list deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

