from flask import Blueprint, request, jsonify, session
from src.models import db
from src.models.user import User
from src.models.org import Org
import re

auth_bp = Blueprint('auth', __name__)

def validate_email(email):
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'password', 'org_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate email format
        if not validate_email(data['email']):
            return jsonify({'error': 'Invalid email format'}), 400
        
        # Check if user already exists
        if User.query.filter_by(email=data['email']).first():
            return jsonify({'error': 'User already exists'}), 400
        
        # Create organization
        org = Org(name=data['org_name'])
        db.session.add(org)
        db.session.flush()  # Get the org ID
        
        # Create user
        user = User(
            name=data['name'],
            email=data['email'],
            org_id=org.id,
            role='owner'  # First user is owner
        )
        user.set_password(data['password'])
        
        db.session.add(user)
        db.session.commit()
        
        # Set session
        session['user_id'] = user.id
        session['org_id'] = org.id
        
        return jsonify({
            'message': 'User registered successfully',
            'user': user.to_dict(),
            'org': org.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        
        if not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email and password are required'}), 400
        
        user = User.query.filter_by(email=data['email']).first()
        
        if not user or not user.check_password(data['password']):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        if not user.is_active:
            return jsonify({'error': 'Account is disabled'}), 401
        
        # Get organization separately to avoid relationship issues
        org = Org.query.get(user.org_id)
        
        # Set session
        session['user_id'] = user.id
        session['org_id'] = user.org_id
        
        return jsonify({
            'message': 'Login successful',
            'user': user.to_dict(),
            'org': org.to_dict() if org else None
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'}), 200

@auth_bp.route('/me', methods=['GET'])
def get_current_user():
    try:
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'Not authenticated'}), 401
        
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get organization separately to avoid relationship issues
        org = Org.query.get(user.org_id)
        
        return jsonify({
            'user': user.to_dict(),
            'org': org.to_dict() if org else None
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    try:
        data = request.get_json()
        
        if not data.get('email'):
            return jsonify({'error': 'Email is required'}), 400
        
        user = User.query.filter_by(email=data['email']).first()
        
        # Always return success for security (don't reveal if email exists)
        return jsonify({'message': 'If the email exists, a reset link has been sent'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Middleware to check authentication
def require_auth():
    user_id = session.get('user_id')
    if not user_id:
        return jsonify({'error': 'Authentication required'}), 401
    
    user = User.query.get(user_id)
    if not user or not user.is_active:
        return jsonify({'error': 'Invalid session'}), 401
    
    return user

def require_role(required_role):
    """Check if user has required role. Roles: owner > admin > agent"""
    user = require_auth()
    if isinstance(user, tuple):  # Error response
        return user
    
    role_hierarchy = {'owner': 3, 'admin': 2, 'agent': 1}
    user_level = role_hierarchy.get(user.role, 0)
    required_level = role_hierarchy.get(required_role, 0)
    
    if user_level < required_level:
        return jsonify({'error': 'Insufficient permissions'}), 403
    
    return user

