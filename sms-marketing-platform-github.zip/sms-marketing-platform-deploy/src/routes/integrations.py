from flask import Blueprint, request, jsonify
from src.models import db
from src.models.integration import Integration
from src.routes.auth import require_auth, require_role
from datetime import datetime

integrations_bp = Blueprint('integrations', __name__)

@integrations_bp.route('/', methods=['GET'])
def get_integrations():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        integrations = Integration.query.filter_by(org_id=user.org_id).all()
        
        return jsonify({
            'integrations': [integration.to_dict() for integration in integrations]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/twilio', methods=['POST'])
def setup_twilio_integration():
    try:
        user = require_role('admin')  # Only admin and owner can manage integrations
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['account_sid', 'auth_token']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Check if Twilio integration already exists
        existing = Integration.query.filter_by(
            org_id=user.org_id,
            type='twilio'
        ).first()
        
        if existing:
            # Update existing integration
            existing.set_credentials({
                'account_sid': data['account_sid'],
                'auth_token': data['auth_token'],
                'messaging_service_sid': data.get('messaging_service_sid')
            })
            existing.status = 'active'
            existing.last_verified_at = datetime.utcnow()
            integration = existing
        else:
            # Create new integration
            integration = Integration(
                org_id=user.org_id,
                type='twilio',
                name='Twilio SMS',
                status='active',
                last_verified_at=datetime.utcnow()
            )
            integration.set_credentials({
                'account_sid': data['account_sid'],
                'auth_token': data['auth_token'],
                'messaging_service_sid': data.get('messaging_service_sid')
            })
            db.session.add(integration)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Twilio integration configured successfully',
            'integration': integration.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/calendly', methods=['POST'])
def setup_calendly_integration():
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        if not data.get('calendly_link'):
            return jsonify({'error': 'Calendly link is required'}), 400
        
        # Check if Calendly integration already exists
        existing = Integration.query.filter_by(
            org_id=user.org_id,
            type='calendly'
        ).first()
        
        if existing:
            # Update existing integration
            existing.set_config({
                'calendly_link': data['calendly_link'],
                'webhook_url': data.get('webhook_url')
            })
            existing.status = 'active'
            integration = existing
        else:
            # Create new integration
            integration = Integration(
                org_id=user.org_id,
                type='calendly',
                name='Calendly Booking',
                status='active'
            )
            integration.set_config({
                'calendly_link': data['calendly_link'],
                'webhook_url': data.get('webhook_url')
            })
            db.session.add(integration)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Calendly integration configured successfully',
            'integration': integration.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/google-calendar', methods=['POST'])
def setup_google_calendar_integration():
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        # In a real implementation, this would handle OAuth flow
        # For now, we'll just store the configuration
        
        existing = Integration.query.filter_by(
            org_id=user.org_id,
            type='gcal'
        ).first()
        
        if existing:
            existing.status = 'active'
            existing.last_verified_at = datetime.utcnow()
            integration = existing
        else:
            integration = Integration(
                org_id=user.org_id,
                type='gcal',
                name='Google Calendar',
                status='active',
                last_verified_at=datetime.utcnow()
            )
            db.session.add(integration)
        
        # In real implementation, store OAuth tokens securely
        integration.set_credentials({
            'access_token': 'mock_access_token',
            'refresh_token': 'mock_refresh_token'
        })
        
        db.session.commit()
        
        return jsonify({
            'message': 'Google Calendar integration configured successfully',
            'integration': integration.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/webhooks', methods=['POST'])
def setup_webhook_integration():
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        required_fields = ['name', 'url', 'events']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate events
        valid_events = ['campaign_launched', 'conversation_created', 'message_inbound', 'meeting_booked']
        events = data['events']
        if not isinstance(events, list) or not all(event in valid_events for event in events):
            return jsonify({'error': f'Invalid events. Valid events: {valid_events}'}), 400
        
        # Create webhook integration
        integration = Integration(
            org_id=user.org_id,
            type='webhook',
            name=data['name'],
            status='active'
        )
        
        integration.set_config({
            'url': data['url'],
            'events': events,
            'secret': data.get('secret', ''),
            'headers': data.get('headers', {})
        })
        
        db.session.add(integration)
        db.session.commit()
        
        return jsonify({
            'message': 'Webhook integration configured successfully',
            'integration': integration.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/<int:integration_id>', methods=['PUT'])
def update_integration(integration_id):
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        integration = Integration.query.filter_by(
            id=integration_id,
            org_id=user.org_id
        ).first()
        
        if not integration:
            return jsonify({'error': 'Integration not found'}), 404
        
        data = request.get_json()
        
        # Update status
        if 'status' in data:
            if data['status'] in ['active', 'inactive']:
                integration.status = data['status']
        
        # Update name
        if 'name' in data:
            integration.name = data['name']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Integration updated successfully',
            'integration': integration.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/<int:integration_id>', methods=['DELETE'])
def delete_integration(integration_id):
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        integration = Integration.query.filter_by(
            id=integration_id,
            org_id=user.org_id
        ).first()
        
        if not integration:
            return jsonify({'error': 'Integration not found'}), 404
        
        db.session.delete(integration)
        db.session.commit()
        
        return jsonify({'message': 'Integration deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@integrations_bp.route('/<int:integration_id>/test', methods=['POST'])
def test_integration(integration_id):
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        integration = Integration.query.filter_by(
            id=integration_id,
            org_id=user.org_id
        ).first()
        
        if not integration:
            return jsonify({'error': 'Integration not found'}), 404
        
        # Mock test results
        test_results = {
            'twilio': {'status': 'success', 'message': 'Twilio connection verified'},
            'calendly': {'status': 'success', 'message': 'Calendly link is valid'},
            'gcal': {'status': 'success', 'message': 'Google Calendar access verified'},
            'webhook': {'status': 'success', 'message': 'Webhook endpoint is reachable'}
        }
        
        result = test_results.get(integration.type, {
            'status': 'error',
            'message': 'Unknown integration type'
        })
        
        if result['status'] == 'success':
            integration.last_verified_at = datetime.utcnow()
            integration.status = 'active'
        else:
            integration.status = 'error'
        
        db.session.commit()
        
        return jsonify({
            'test_result': result,
            'integration': integration.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

