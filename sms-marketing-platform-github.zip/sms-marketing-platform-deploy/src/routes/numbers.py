from flask import Blueprint, request, jsonify
from src.models import db
from src.models.sending_number import SendingNumber
from src.routes.auth import require_auth, require_role
import re

numbers_bp = Blueprint('numbers', __name__)

@numbers_bp.route('/', methods=['GET'])
def get_numbers():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        numbers = SendingNumber.query.filter_by(org_id=user.org_id).order_by(SendingNumber.created_at.desc()).all()
        
        return jsonify({
            'numbers': [num.to_dict() for num in numbers]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@numbers_bp.route('/purchase', methods=['POST'])
def purchase_number():
    try:
        user = require_role('admin')  # Only admin and owner can purchase numbers
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        # Validate input
        area_code = data.get('area_code')
        country = data.get('country', 'US')
        
        if not area_code and country == 'US':
            return jsonify({'error': 'Area code is required for US numbers'}), 400
        
        # In a real implementation, this would call Twilio API
        # For now, we'll create a mock number
        if country == 'US' and area_code:
            # Generate a mock US number
            mock_number = f"+1{area_code}5551234"
        else:
            # Generate a mock international number
            mock_number = "+15555551234"
        
        # Check if number already exists
        existing = SendingNumber.query.filter_by(phone=mock_number).first()
        if existing:
            return jsonify({'error': 'Number already exists in system'}), 400
        
        # Create sending number
        sending_number = SendingNumber(
            org_id=user.org_id,
            phone=mock_number,
            provider='twilio',
            daily_cap=200,
            status='active',
            provider_sid=f'PN{mock_number.replace("+", "").replace("-", "")}'
        )
        
        db.session.add(sending_number)
        db.session.commit()
        
        return jsonify({
            'message': 'Number purchased successfully',
            'number': sending_number.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@numbers_bp.route('/<int:number_id>', methods=['PUT'])
def update_number(number_id):
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        number = SendingNumber.query.filter_by(id=number_id, org_id=user.org_id).first()
        if not number:
            return jsonify({'error': 'Number not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        if 'status' in data:
            if data['status'] in ['active', 'disabled']:
                number.status = data['status']
        
        if 'daily_cap' in data:
            daily_cap = int(data['daily_cap'])
            if daily_cap > 0 and daily_cap <= 1000:  # Reasonable limits
                number.daily_cap = daily_cap
        
        db.session.commit()
        
        return jsonify({
            'message': 'Number updated successfully',
            'number': number.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@numbers_bp.route('/<int:number_id>', methods=['DELETE'])
def delete_number(number_id):
    try:
        user = require_role('admin')
        if isinstance(user, tuple):
            return user
        
        number = SendingNumber.query.filter_by(id=number_id, org_id=user.org_id).first()
        if not number:
            return jsonify({'error': 'Number not found'}), 404
        
        # Check if number is being used in any active campaigns
        from src.models.campaign import Campaign
        import json
        
        active_campaigns = Campaign.query.filter(
            Campaign.org_id == user.org_id,
            Campaign.status.in_(['running', 'scheduled'])
        ).all()
        
        for campaign in active_campaigns:
            if campaign.numbers_assigned_list and number_id in campaign.numbers_assigned_list:
                return jsonify({'error': 'Cannot delete number that is assigned to active campaigns'}), 400
        
        # In a real implementation, this would also release the number from Twilio
        db.session.delete(number)
        db.session.commit()
        
        return jsonify({'message': 'Number deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@numbers_bp.route('/available-areas', methods=['GET'])
def get_available_areas():
    """Get available area codes for number purchase"""
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Mock data - in real implementation, this would query Twilio
        available_areas = [
            {'area_code': '212', 'location': 'New York, NY'},
            {'area_code': '213', 'location': 'Los Angeles, CA'},
            {'area_code': '312', 'location': 'Chicago, IL'},
            {'area_code': '415', 'location': 'San Francisco, CA'},
            {'area_code': '617', 'location': 'Boston, MA'},
            {'area_code': '713', 'location': 'Houston, TX'},
            {'area_code': '305', 'location': 'Miami, FL'},
            {'area_code': '206', 'location': 'Seattle, WA'},
            {'area_code': '404', 'location': 'Atlanta, GA'},
            {'area_code': '702', 'location': 'Las Vegas, NV'}
        ]
        
        return jsonify({
            'available_areas': available_areas
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

