from flask import Blueprint, request, jsonify
from src.models import db
from src.models.message import Message
from src.models.conversation import Conversation
from src.models.lead import Lead
from src.models.meeting_event import MeetingEvent
from src.models.analytics_daily import AnalyticsDaily
from datetime import datetime
import json

webhooks_bp = Blueprint('webhooks', __name__)

@webhooks_bp.route('/twilio/inbound', methods=['POST'])
def twilio_inbound_webhook():
    try:
        # Get Twilio webhook data
        data = request.form.to_dict()
        
        from_number = data.get('From')
        to_number = data.get('To')
        body = data.get('Body', '')
        message_sid = data.get('MessageSid')
        
        if not all([from_number, to_number, body, message_sid]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Find or create lead
        lead = Lead.query.filter_by(phone=from_number).first()
        if not lead:
            # Create unknown lead
            from src.models.lead_list import LeadList
            
            # Find or create an "Unknown" lead list
            unknown_list = LeadList.query.filter_by(name='Unknown Contacts').first()
            if not unknown_list:
                # We need to determine the org_id from the receiving number
                from src.models.sending_number import SendingNumber
                sending_number = SendingNumber.query.filter_by(phone=to_number).first()
                if not sending_number:
                    return jsonify({'error': 'Receiving number not found'}), 404
                
                unknown_list = LeadList(
                    org_id=sending_number.org_id,
                    name='Unknown Contacts',
                    source='inbound',
                    status='ready'
                )
                db.session.add(unknown_list)
                db.session.flush()
            
            lead = Lead(
                lead_list_id=unknown_list.id,
                name=f'Unknown {from_number}',
                phone=from_number,
                valid=True
            )
            db.session.add(lead)
            db.session.flush()
        
        # Find or create conversation
        conversation = Conversation.query.filter_by(
            org_id=lead.lead_list.org_id,
            lead_id=lead.id
        ).first()
        
        if not conversation:
            conversation = Conversation(
                org_id=lead.lead_list.org_id,
                lead_id=lead.id
            )
            db.session.add(conversation)
            db.session.flush()
        
        # Create inbound message
        message = Message(
            conversation_id=conversation.id,
            to_number=to_number,
            from_number=from_number,
            direction='inbound',
            body=body,
            status='received',
            provider_message_id=message_sid,
            created_at=datetime.utcnow()
        )
        
        db.session.add(message)
        
        # Update conversation timestamp
        conversation.latest_message_at = datetime.utcnow()
        
        # Update analytics
        analytics = AnalyticsDaily.get_or_create_for_date(lead.lead_list.org_id)
        analytics.inbound_count += 1
        
        db.session.commit()
        
        # Check for AI responder logic here
        # For now, just acknowledge receipt
        
        return jsonify({'status': 'received'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/twilio/status', methods=['POST'])
def twilio_status_webhook():
    try:
        data = request.form.to_dict()
        
        message_sid = data.get('MessageSid')
        message_status = data.get('MessageStatus')
        
        if not message_sid or not message_status:
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Find message by provider ID
        message = Message.query.filter_by(provider_message_id=message_sid).first()
        if not message:
            return jsonify({'error': 'Message not found'}), 404
        
        # Update message status
        message.status = message_status
        
        if message_status == 'sent':
            message.sent_at = datetime.utcnow()
        elif message_status == 'delivered':
            message.delivered_at = datetime.utcnow()
        elif message_status == 'failed':
            message.failed_at = datetime.utcnow()
            message.error_message = data.get('ErrorMessage', 'Unknown error')
        
        db.session.commit()
        
        return jsonify({'status': 'updated'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/calendly/booking', methods=['POST'])
def calendly_booking_webhook():
    try:
        data = request.get_json()
        
        # Parse Calendly webhook payload
        event = data.get('event')
        payload = data.get('payload', {})
        
        if event != 'invitee.created':
            return jsonify({'status': 'ignored'}), 200
        
        # Extract booking information
        invitee = payload.get('invitee', {})
        event_details = payload.get('event', {})
        
        email = invitee.get('email')
        phone = invitee.get('text_reminder_number')  # If provided
        start_time = event_details.get('start_time')
        event_uri = invitee.get('uri')
        
        if not email:
            return jsonify({'error': 'Email is required'}), 400
        
        # Find lead by email or phone
        lead = None
        if phone:
            lead = Lead.query.filter_by(phone=phone).first()
        if not lead and email:
            lead = Lead.query.filter_by(email=email).first()
        
        if not lead:
            return jsonify({'error': 'Lead not found'}), 404
        
        # Create meeting event
        meeting_event = MeetingEvent(
            org_id=lead.lead_list.org_id,
            lead_id=lead.id,
            source='calendly',
            start_time=datetime.fromisoformat(start_time.replace('Z', '+00:00')) if start_time else None,
            link=event_uri,
            status='scheduled'
        )
        
        db.session.add(meeting_event)
        
        # Update analytics
        analytics = AnalyticsDaily.get_or_create_for_date(lead.lead_list.org_id)
        analytics.meetings_booked += 1
        
        db.session.commit()
        
        return jsonify({'status': 'meeting_created'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/make/trigger', methods=['POST'])
def make_trigger_webhook():
    """Webhook endpoint for Make.com integrations"""
    try:
        data = request.get_json()
        
        # Validate webhook signature if provided
        # In a real implementation, verify the signature
        
        event_type = data.get('event_type')
        payload = data.get('payload', {})
        
        # Process different event types
        if event_type == 'campaign_launched':
            # Handle campaign launch event
            campaign_id = payload.get('campaign_id')
            # Process campaign launch logic
            
        elif event_type == 'message_inbound':
            # Handle inbound message event
            message_id = payload.get('message_id')
            # Process inbound message logic
            
        elif event_type == 'meeting_booked':
            # Handle meeting booking event
            meeting_id = payload.get('meeting_id')
            # Process meeting booking logic
            
        return jsonify({'status': 'processed'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/n8n/trigger', methods=['POST'])
def n8n_trigger_webhook():
    """Webhook endpoint for n8n integrations"""
    try:
        data = request.get_json()
        
        # Similar to Make.com webhook but for n8n
        event_type = data.get('event_type')
        payload = data.get('payload', {})
        
        # Process events for n8n
        # Implementation similar to Make.com webhook
        
        return jsonify({'status': 'processed'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Webhook endpoints for external services to trigger
@webhooks_bp.route('/hooks/campaign/launched', methods=['POST'])
def campaign_launched_hook():
    """Signed webhook for campaign launch events"""
    try:
        data = request.get_json()
        
        # Verify signature (implement signature verification)
        # signature = request.headers.get('X-Webhook-Signature')
        
        campaign_id = data.get('campaign_id')
        if not campaign_id:
            return jsonify({'error': 'campaign_id is required'}), 400
        
        # Trigger external webhooks for this event
        from src.models.campaign import Campaign
        campaign = Campaign.query.get(campaign_id)
        if campaign:
            # Send to configured webhooks
            # Implementation for webhook delivery
            pass
        
        return jsonify({'status': 'delivered'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/hooks/conversation/created', methods=['POST'])
def conversation_created_hook():
    """Signed webhook for new conversation events"""
    try:
        data = request.get_json()
        
        conversation_id = data.get('conversation_id')
        if not conversation_id:
            return jsonify({'error': 'conversation_id is required'}), 400
        
        # Process and deliver to external webhooks
        return jsonify({'status': 'delivered'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/hooks/message/inbound', methods=['POST'])
def message_inbound_hook():
    """Signed webhook for inbound message events"""
    try:
        data = request.get_json()
        
        message_id = data.get('message_id')
        if not message_id:
            return jsonify({'error': 'message_id is required'}), 400
        
        # Process and deliver to external webhooks
        return jsonify({'status': 'delivered'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@webhooks_bp.route('/hooks/meeting/booked', methods=['POST'])
def meeting_booked_hook():
    """Signed webhook for meeting booking events"""
    try:
        data = request.get_json()
        
        meeting_id = data.get('meeting_id')
        if not meeting_id:
            return jsonify({'error': 'meeting_id is required'}), 400
        
        # Process and deliver to external webhooks
        return jsonify({'status': 'delivered'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

