from flask import Blueprint, request, jsonify
from src.models import db
from src.models.conversation import Conversation
from src.models.message import Message
from src.models.lead import Lead
from src.models.campaign import Campaign
from src.routes.auth import require_auth
from datetime import datetime

conversations_bp = Blueprint('conversations', __name__)

@conversations_bp.route('/', methods=['GET'])
def get_conversations():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Get conversations with pagination
        conversations_query = Conversation.query.filter_by(org_id=user.org_id).order_by(
            Conversation.latest_message_at.desc()
        )
        
        conversations_paginated = conversations_query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'conversations': [conv.to_dict() for conv in conversations_paginated.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': conversations_paginated.total,
                'pages': conversations_paginated.pages,
                'has_next': conversations_paginated.has_next,
                'has_prev': conversations_paginated.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@conversations_bp.route('/<int:conversation_id>', methods=['GET'])
def get_conversation(conversation_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        conversation = Conversation.query.filter_by(id=conversation_id, org_id=user.org_id).first()
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        return jsonify({
            'conversation': conversation.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@conversations_bp.route('/<int:conversation_id>/messages', methods=['GET'])
def get_conversation_messages(conversation_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Verify conversation belongs to user's org
        conversation = Conversation.query.filter_by(id=conversation_id, org_id=user.org_id).first()
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 50, type=int)
        
        # Get messages with pagination (newest first)
        messages_query = Message.query.filter_by(conversation_id=conversation_id).order_by(
            Message.created_at.desc()
        )
        
        messages_paginated = messages_query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        # Reverse the items to show oldest first in the UI
        messages = list(reversed(messages_paginated.items))
        
        return jsonify({
            'messages': [msg.to_dict() for msg in messages],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': messages_paginated.total,
                'pages': messages_paginated.pages,
                'has_next': messages_paginated.has_next,
                'has_prev': messages_paginated.has_prev
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@conversations_bp.route('/<int:conversation_id>/messages', methods=['POST'])
def send_message(conversation_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        # Verify conversation belongs to user's org
        conversation = Conversation.query.filter_by(id=conversation_id, org_id=user.org_id).first()
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        data = request.get_json()
        
        if not data.get('body'):
            return jsonify({'error': 'Message body is required'}), 400
        
        # Get lead and determine sending number
        lead = conversation.lead
        if not lead:
            return jsonify({'error': 'Lead not found'}), 404
        
        # Find an available sending number for this org
        from src.models.sending_number import SendingNumber
        sending_number = SendingNumber.query.filter_by(
            org_id=user.org_id,
            status='active'
        ).first()
        
        if not sending_number:
            return jsonify({'error': 'No active sending numbers available'}), 400
        
        # Check daily limit
        if sending_number.remaining_today <= 0:
            return jsonify({'error': 'Daily sending limit reached for available numbers'}), 400
        
        # Create message
        message = Message(
            conversation_id=conversation_id,
            to_number=lead.phone,
            from_number=sending_number.phone,
            direction='outbound',
            body=data['body'],
            status='queued'
        )
        
        db.session.add(message)
        
        # Update conversation timestamp
        conversation.latest_message_at = datetime.utcnow()
        
        db.session.commit()
        
        # In a real implementation, this would queue the message for sending via Twilio
        # For now, we'll simulate immediate sending
        message.status = 'sent'
        message.sent_at = datetime.utcnow()
        db.session.commit()
        
        return jsonify({
            'message': 'Message sent successfully',
            'message_data': message.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@conversations_bp.route('/<int:conversation_id>/ai/pause', methods=['POST'])
def toggle_ai_pause(conversation_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        conversation = Conversation.query.filter_by(id=conversation_id, org_id=user.org_id).first()
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        data = request.get_json()
        paused = data.get('paused', not conversation.ai_paused_for_thread)
        
        conversation.ai_paused_for_thread = paused
        db.session.commit()
        
        status = 'paused' if paused else 'resumed'
        return jsonify({
            'message': f'AI responder {status} for this conversation',
            'ai_paused': paused
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@conversations_bp.route('/search', methods=['GET'])
def search_conversations():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        query = request.args.get('q', '').strip()
        if not query:
            return jsonify({'conversations': []}), 200
        
        # Search in lead names, phone numbers, and companies
        conversations = db.session.query(Conversation).join(Lead).filter(
            Conversation.org_id == user.org_id,
            db.or_(
                Lead.name.ilike(f'%{query}%'),
                Lead.phone.ilike(f'%{query}%'),
                Lead.company.ilike(f'%{query}%'),
                Lead.email.ilike(f'%{query}%')
            )
        ).order_by(Conversation.latest_message_at.desc()).limit(20).all()
        
        return jsonify({
            'conversations': [conv.to_dict() for conv in conversations]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@conversations_bp.route('/<int:conversation_id>/meeting-link', methods=['POST'])
def send_meeting_link(conversation_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        conversation = Conversation.query.filter_by(id=conversation_id, org_id=user.org_id).first()
        if not conversation:
            return jsonify({'error': 'Conversation not found'}), 404
        
        data = request.get_json()
        meeting_link = data.get('meeting_link')
        
        if not meeting_link:
            return jsonify({'error': 'Meeting link is required'}), 400
        
        # Create a message with the meeting link
        lead = conversation.lead
        from src.models.sending_number import SendingNumber
        
        sending_number = SendingNumber.query.filter_by(
            org_id=user.org_id,
            status='active'
        ).first()
        
        if not sending_number:
            return jsonify({'error': 'No active sending numbers available'}), 400
        
        message_body = f"Here's the link to book a meeting: {meeting_link}"
        
        message = Message(
            conversation_id=conversation_id,
            to_number=lead.phone,
            from_number=sending_number.phone,
            direction='outbound',
            body=message_body,
            status='sent',
            sent_at=datetime.utcnow()
        )
        
        db.session.add(message)
        conversation.latest_message_at = datetime.utcnow()
        db.session.commit()
        
        # Track meeting link sent
        from src.models.analytics_daily import AnalyticsDaily
        analytics = AnalyticsDaily.get_or_create_for_date(user.org_id)
        analytics.meeting_links_sent += 1
        db.session.commit()
        
        return jsonify({
            'message': 'Meeting link sent successfully',
            'message_data': message.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

