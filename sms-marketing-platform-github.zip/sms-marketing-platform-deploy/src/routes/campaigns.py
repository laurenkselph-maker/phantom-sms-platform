from flask import Blueprint, request, jsonify
from src.models import db
from src.models.campaign import Campaign
from src.models.lead_list import LeadList
from src.models.sending_number import SendingNumber
from src.models.lead import Lead
from src.models.conversation import Conversation
from src.models.message import Message
from src.routes.auth import require_auth
from datetime import datetime, timedelta
import json

campaigns_bp = Blueprint('campaigns', __name__)

@campaigns_bp.route('/', methods=['GET'])
def get_campaigns():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaigns = Campaign.query.filter_by(org_id=user.org_id).order_by(Campaign.created_at.desc()).all()
        
        return jsonify({
            'campaigns': [campaign.to_dict() for campaign in campaigns]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/', methods=['POST'])
def create_campaign():
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'base_message', 'lead_list_id', 'numbers_assigned']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate lead list exists and belongs to org
        lead_list = LeadList.query.filter_by(id=data['lead_list_id'], org_id=user.org_id).first()
        if not lead_list:
            return jsonify({'error': 'Lead list not found'}), 404
        
        if lead_list.status != 'ready':
            return jsonify({'error': 'Lead list is not ready for campaigns'}), 400
        
        # Validate sending numbers
        number_ids = data['numbers_assigned']
        if not isinstance(number_ids, list) or len(number_ids) == 0:
            return jsonify({'error': 'At least one sending number must be assigned'}), 400
        
        # Check all numbers exist and belong to org
        numbers = SendingNumber.query.filter(
            SendingNumber.id.in_(number_ids),
            SendingNumber.org_id == user.org_id,
            SendingNumber.status == 'active'
        ).all()
        
        if len(numbers) != len(number_ids):
            return jsonify({'error': 'One or more sending numbers not found or inactive'}), 400
        
        # Validate audience size constraint
        max_leads_allowed = len(number_ids) * 200
        if lead_list.size > max_leads_allowed:
            return jsonify({
                'error': f'Lead list has {lead_list.size} leads but only {max_leads_allowed} allowed with {len(number_ids)} numbers'
            }), 400
        
        # Validate AI responder settings
        ai_responder = data.get('ai_responder', False)
        meeting_link_url = data.get('meeting_link_url')
        
        if ai_responder and not meeting_link_url:
            return jsonify({'error': 'Meeting link URL is required when AI responder is enabled'}), 400
        
        # Parse start time
        start_at = None
        if data.get('start_at'):
            try:
                start_at = datetime.fromisoformat(data['start_at'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'error': 'Invalid start_at format. Use ISO format.'}), 400
        
        # Create campaign
        campaign = Campaign(
            org_id=user.org_id,
            name=data['name'],
            base_message=data['base_message'],
            ai_responder=ai_responder,
            meeting_link_url=meeting_link_url,
            lead_list_id=data['lead_list_id'],
            start_at=start_at,
            status='draft'
        )
        
        # Set numbers assigned
        campaign.numbers_assigned_list = number_ids
        
        db.session.add(campaign)
        db.session.commit()
        
        return jsonify({
            'message': 'Campaign created successfully',
            'campaign': campaign.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/<int:campaign_id>', methods=['GET'])
def get_campaign(campaign_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaign = Campaign.query.filter_by(id=campaign_id, org_id=user.org_id).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        return jsonify({
            'campaign': campaign.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/<int:campaign_id>', methods=['PUT'])
def update_campaign(campaign_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaign = Campaign.query.filter_by(id=campaign_id, org_id=user.org_id).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        # Check if campaign is launched (immutable constraints)
        if campaign.status in ['running', 'completed']:
            return jsonify({'error': 'Cannot modify launched campaigns'}), 400
        
        data = request.get_json()
        
        # Update allowed fields for draft/scheduled campaigns
        if 'name' in data:
            campaign.name = data['name']
        
        if 'base_message' in data:
            campaign.base_message = data['base_message']
        
        # AI responder and meeting link are immutable after launch
        if campaign.status == 'draft':
            if 'ai_responder' in data:
                campaign.ai_responder = data['ai_responder']
            
            if 'meeting_link_url' in data:
                campaign.meeting_link_url = data['meeting_link_url']
        
        if 'start_at' in data:
            try:
                campaign.start_at = datetime.fromisoformat(data['start_at'].replace('Z', '+00:00'))
            except ValueError:
                return jsonify({'error': 'Invalid start_at format'}), 400
        
        db.session.commit()
        
        return jsonify({
            'message': 'Campaign updated successfully',
            'campaign': campaign.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/<int:campaign_id>/launch', methods=['POST'])
def launch_campaign(campaign_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaign = Campaign.query.filter_by(id=campaign_id, org_id=user.org_id).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        if campaign.status != 'draft':
            return jsonify({'error': 'Only draft campaigns can be launched'}), 400
        
        # Validate campaign is ready to launch
        if not campaign.base_message:
            return jsonify({'error': 'Campaign message is required'}), 400
        
        if not campaign.numbers_assigned_list:
            return jsonify({'error': 'At least one sending number must be assigned'}), 400
        
        # Check if start time is in the future or immediate
        now = datetime.utcnow()
        if campaign.start_at and campaign.start_at > now:
            campaign.status = 'scheduled'
        else:
            campaign.status = 'running'
            campaign.start_at = now
        
        campaign.launched_at = now
        
        # Create conversations for all leads in the list
        leads = Lead.query.filter_by(lead_list_id=campaign.lead_list_id, valid=True).all()
        
        for lead in leads:
            # Check if conversation already exists
            existing_conv = Conversation.query.filter_by(
                org_id=user.org_id,
                lead_id=lead.id
            ).first()
            
            if not existing_conv:
                conversation = Conversation(
                    org_id=user.org_id,
                    lead_id=lead.id
                )
                db.session.add(conversation)
        
        db.session.commit()
        
        # In a real implementation, this would queue the messages for sending
        # For now, we'll just mark as launched
        
        return jsonify({
            'message': 'Campaign launched successfully',
            'campaign': campaign.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/<int:campaign_id>/pause', methods=['POST'])
def pause_campaign(campaign_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaign = Campaign.query.filter_by(id=campaign_id, org_id=user.org_id).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        if campaign.status not in ['running', 'scheduled']:
            return jsonify({'error': 'Only running or scheduled campaigns can be paused'}), 400
        
        campaign.status = 'paused'
        db.session.commit()
        
        return jsonify({
            'message': 'Campaign paused successfully',
            'campaign': campaign.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/<int:campaign_id>/resume', methods=['POST'])
def resume_campaign(campaign_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaign = Campaign.query.filter_by(id=campaign_id, org_id=user.org_id).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        if campaign.status != 'paused':
            return jsonify({'error': 'Only paused campaigns can be resumed'}), 400
        
        campaign.status = 'running'
        db.session.commit()
        
        return jsonify({
            'message': 'Campaign resumed successfully',
            'campaign': campaign.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@campaigns_bp.route('/<int:campaign_id>', methods=['DELETE'])
def delete_campaign(campaign_id):
    try:
        user = require_auth()
        if isinstance(user, tuple):
            return user
        
        campaign = Campaign.query.filter_by(id=campaign_id, org_id=user.org_id).first()
        if not campaign:
            return jsonify({'error': 'Campaign not found'}), 404
        
        if campaign.status in ['running']:
            return jsonify({'error': 'Cannot delete running campaigns. Pause first.'}), 400
        
        db.session.delete(campaign)
        db.session.commit()
        
        return jsonify({'message': 'Campaign deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

