from datetime import datetime
from . import db

class LeadList(db.Model):
    __tablename__ = 'lead_lists'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), nullable=False, default='ready')  # ready, sourcing, error
    source = db.Column(db.String(20), nullable=False)  # upload, purchase
    tam_criteria = db.Column(db.Text)  # JSON string for purchase requests
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<LeadList {self.name}>'

    @property
    def size(self):
        from .lead import Lead
        return Lead.query.filter_by(lead_list_id=self.id).count()

    def to_dict(self):
        return {
            'id': self.id,
            'org_id': self.org_id,
            'name': self.name,
            'status': self.status,
            'source': self.source,
            'size': self.size,
            'tam_criteria': self.tam_criteria,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

