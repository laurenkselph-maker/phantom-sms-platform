from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

# Import all models to ensure they are registered
from .user import User
from .org import Org
from .lead_list import LeadList
from .lead import Lead
from .sending_number import SendingNumber
from .campaign import Campaign
from .message import Message
from .conversation import Conversation
from .meeting_event import MeetingEvent
from .integration import Integration
from .analytics_daily import AnalyticsDaily

