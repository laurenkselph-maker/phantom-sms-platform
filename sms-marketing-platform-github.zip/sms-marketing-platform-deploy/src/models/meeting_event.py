from datetime import datetime
from . import db

class MeetingEvent(db.Model):
    __tablename__ = 'meeting_events'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    lead_id = db.Column(db.Integer, db.ForeignKey('leads.id'), nullable=False)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'))
    source = db.Column(db.String(20), nullable=False)  # calendly, gcal, manual
    start_time = db.Column(db.DateTime)
    link = db.Column(db.String(500))
    status = db.Column(db.String(20), default='scheduled')  # scheduled, completed, cancelled
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships

    def __repr__(self):
        return f'<MeetingEvent {self.lead_id} - {self.source}>'

    def to_dict(self):
        return {
            'id': self.id,
            'org_id': self.org_id,
            'lead_id': self.lead_id,
            'campaign_id': self.campaign_id,
            'source': self.source,
            'start_time': self.start_time.isoformat() if self.start_time else None,
            'link': self.link,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

