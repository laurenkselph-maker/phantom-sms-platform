from datetime import datetime
from . import db

class Conversation(db.Model):
    __tablename__ = 'conversations'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    lead_id = db.Column(db.Integer, db.ForeignKey('leads.id'), nullable=False)
    latest_message_at = db.Column(db.DateTime, default=datetime.utcnow)
    ai_paused_for_thread = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships

    def __repr__(self):
        return f'<Conversation {self.lead_id}>'

    @property
    def latest_message(self):
        """Get the latest message in this conversation"""
        return self.messages.order_by(Message.created_at.desc()).first() if self.messages else None

    @property
    def unread_count(self):
        """Get count of unread inbound messages"""
        # For now, we'll consider all inbound messages as unread
        # In a real app, you'd track read status
        return len([m for m in self.messages if m.direction == 'inbound'])

    def to_dict(self):
        latest_msg = self.latest_message
        return {
            'id': self.id,
            'org_id': self.org_id,
            'lead_id': self.lead_id,
            'lead': self.lead.to_dict() if self.lead else None,
            'latest_message_at': self.latest_message_at.isoformat() if self.latest_message_at else None,
            'latest_message': latest_msg.to_dict() if latest_msg else None,
            'unread_count': self.unread_count,
            'ai_paused_for_thread': self.ai_paused_for_thread,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

