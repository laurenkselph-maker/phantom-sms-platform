from datetime import datetime, date
from . import db

class SendingNumber(db.Model):
    __tablename__ = 'sending_numbers'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    phone = db.Column(db.String(20), nullable=False, unique=True)  # E.164 format
    provider = db.Column(db.String(20), nullable=False, default='twilio')
    daily_cap = db.Column(db.Integer, nullable=False, default=200)
    timezone = db.Column(db.String(50), default='UTC')
    status = db.Column(db.String(20), nullable=False, default='active')  # active, disabled
    provider_sid = db.Column(db.String(100))  # Twilio SID or other provider ID
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships

    def __repr__(self):
        return f'<SendingNumber {self.phone}>'

    @property
    def daily_sent_count(self):
        """Get count of messages sent today from this number"""
        from .message import Message
        today = date.today()
        return Message.query.filter(
            Message.from_number == self.phone,
            Message.direction == 'outbound',
            db.func.date(Message.created_at) == today
        ).count()

    @property
    def remaining_today(self):
        """Get remaining sends for today"""
        return max(0, self.daily_cap - self.daily_sent_count)

    def to_dict(self):
        return {
            'id': self.id,
            'org_id': self.org_id,
            'phone': self.phone,
            'provider': self.provider,
            'daily_cap': self.daily_cap,
            'daily_sent_count': self.daily_sent_count,
            'remaining_today': self.remaining_today,
            'timezone': self.timezone,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

