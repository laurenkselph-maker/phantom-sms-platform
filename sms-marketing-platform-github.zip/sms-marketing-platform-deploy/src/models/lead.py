from datetime import datetime
from . import db

class Lead(db.Model):
    __tablename__ = 'leads'
    
    id = db.Column(db.Integer, primary_key=True)
    lead_list_id = db.Column(db.Integer, db.ForeignKey('lead_lists.id'), nullable=False)
    name = db.Column(db.String(100))
    phone = db.Column(db.String(20), nullable=False)  # E.164 format
    email = db.Column(db.String(120))
    title = db.Column(db.String(100))
    company = db.Column(db.String(100))
    industry = db.Column(db.String(100))
    location = db.Column(db.String(100))
    notes = db.Column(db.Text)
    valid = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships

    def __repr__(self):
        return f'<Lead {self.name} - {self.phone}>'

    def to_dict(self):
        return {
            'id': self.id,
            'lead_list_id': self.lead_list_id,
            'name': self.name,
            'phone': self.phone,
            'email': self.email,
            'title': self.title,
            'company': self.company,
            'industry': self.industry,
            'location': self.location,
            'notes': self.notes,
            'valid': self.valid,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

