from datetime import datetime, date
from . import db

class AnalyticsDaily(db.Model):
    __tablename__ = 'analytics_daily'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    outbound_count = db.Column(db.Integer, default=0)
    inbound_count = db.Column(db.Integer, default=0)
    meetings_booked = db.Column(db.Integer, default=0)
    meeting_links_sent = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships

    # Unique constraint on org_id and date
    __table_args__ = (db.UniqueConstraint('org_id', 'date', name='unique_org_date'),)

    def __repr__(self):
        return f'<AnalyticsDaily {self.org_id} - {self.date}>'

    @classmethod
    def get_or_create_for_date(cls, org_id, target_date=None):
        """Get or create analytics record for a specific date"""
        if target_date is None:
            target_date = date.today()
        
        record = cls.query.filter_by(org_id=org_id, date=target_date).first()
        if not record:
            record = cls(org_id=org_id, date=target_date)
            db.session.add(record)
            db.session.commit()
        return record

    def to_dict(self):
        return {
            'id': self.id,
            'org_id': self.org_id,
            'date': self.date.isoformat() if self.date else None,
            'outbound_count': self.outbound_count,
            'inbound_count': self.inbound_count,
            'meetings_booked': self.meetings_booked,
            'meeting_links_sent': self.meeting_links_sent,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

