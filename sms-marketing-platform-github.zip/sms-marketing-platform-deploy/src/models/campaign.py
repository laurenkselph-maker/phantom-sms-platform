from datetime import datetime
import json
from . import db

class Campaign(db.Model):
    __tablename__ = 'campaigns'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    base_message = db.Column(db.Text, nullable=False)
    ai_responder = db.Column(db.Boolean, nullable=False, default=False)
    meeting_link_url = db.Column(db.String(500))
    status = db.Column(db.String(20), nullable=False, default='draft')  # draft, scheduled, running, paused, completed
    start_at = db.Column(db.DateTime)
    lead_list_id = db.Column(db.Integer, db.ForeignKey('lead_lists.id'), nullable=False)
    numbers_assigned = db.Column(db.Text)  # JSON array of sending_number IDs
    max_leads_allowed = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    launched_at = db.Column(db.DateTime)

    # Relationships

    def __repr__(self):
        return f'<Campaign {self.name}>'

    @property
    def numbers_assigned_list(self):
        """Get list of assigned number IDs"""
        if self.numbers_assigned:
            return json.loads(self.numbers_assigned)
        return []

    @numbers_assigned_list.setter
    def numbers_assigned_list(self, value):
        """Set list of assigned number IDs"""
        self.numbers_assigned = json.dumps(value)
        self.max_leads_allowed = len(value) * 200

    @property
    def sent_count(self):
        """Get count of sent messages for this campaign"""
        return len([m for m in self.messages if m.direction == 'outbound'])

    @property
    def replies_count(self):
        """Get count of inbound replies for this campaign"""
        return len([m for m in self.messages if m.direction == 'inbound'])

    @property
    def meetings_count(self):
        """Get count of meetings booked from this campaign"""
        from .meeting_event import MeetingEvent
        return MeetingEvent.query.filter_by(campaign_id=self.id).count()

    def to_dict(self):
        return {
            'id': self.id,
            'org_id': self.org_id,
            'name': self.name,
            'base_message': self.base_message,
            'ai_responder': self.ai_responder,
            'meeting_link_url': self.meeting_link_url,
            'status': self.status,
            'start_at': self.start_at.isoformat() if self.start_at else None,
            'lead_list_id': self.lead_list_id,
            'numbers_assigned': self.numbers_assigned_list,
            'max_leads_allowed': self.max_leads_allowed,
            'sent_count': self.sent_count,
            'replies_count': self.replies_count,
            'meetings_count': self.meetings_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'launched_at': self.launched_at.isoformat() if self.launched_at else None
        }

