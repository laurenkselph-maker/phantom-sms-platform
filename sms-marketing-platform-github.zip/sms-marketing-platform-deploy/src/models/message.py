from datetime import datetime
from . import db

class Message(db.Model):
    __tablename__ = 'messages'
    
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaigns.id'))  # nullable for ad-hoc messages
    conversation_id = db.Column(db.Integer, db.ForeignKey('conversations.id'), nullable=False)
    to_number = db.Column(db.String(20), nullable=False)  # E.164 format
    from_number = db.Column(db.String(20), nullable=False)  # E.164 format
    direction = db.Column(db.String(10), nullable=False)  # outbound, inbound
    body = db.Column(db.Text, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='queued')  # queued, sent, delivered, failed, received
    provider_message_id = db.Column(db.String(100))  # Twilio SID or other provider ID
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    sent_at = db.Column(db.DateTime)
    delivered_at = db.Column(db.DateTime)
    failed_at = db.Column(db.DateTime)
    error_message = db.Column(db.Text)

    # Relationships

    def __repr__(self):
        return f'<Message {self.direction} {self.to_number}>'

    def to_dict(self):
        return {
            'id': self.id,
            'campaign_id': self.campaign_id,
            'conversation_id': self.conversation_id,
            'to_number': self.to_number,
            'from_number': self.from_number,
            'direction': self.direction,
            'body': self.body,
            'status': self.status,
            'provider_message_id': self.provider_message_id,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'sent_at': self.sent_at.isoformat() if self.sent_at else None,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'failed_at': self.failed_at.isoformat() if self.failed_at else None,
            'error_message': self.error_message
        }

