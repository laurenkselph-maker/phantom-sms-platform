from datetime import datetime
import json
from . import db

class Integration(db.Model):
    __tablename__ = 'integrations'
    
    id = db.Column(db.Integer, primary_key=True)
    org_id = db.Column(db.Integer, db.ForeignKey('orgs.id'), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # twilio, calendly, gcal, webhook
    name = db.Column(db.String(100))
    credentials = db.Column(db.Text)  # Encrypted JSON
    config = db.Column(db.Text)  # Additional configuration as JSON
    status = db.Column(db.String(20), nullable=False, default='inactive')  # active, inactive, error
    last_verified_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationships

    def __repr__(self):
        return f'<Integration {self.type} - {self.org_id}>'

    def get_credentials(self):
        """Get decrypted credentials"""
        if self.credentials:
            # In a real app, you'd decrypt this
            return json.loads(self.credentials)
        return {}

    def set_credentials(self, creds_dict):
        """Set encrypted credentials"""
        # In a real app, you'd encrypt this
        self.credentials = json.dumps(creds_dict)

    def get_config(self):
        """Get configuration as dict"""
        if self.config:
            return json.loads(self.config)
        return {}

    def set_config(self, config_dict):
        """Set configuration"""
        self.config = json.dumps(config_dict)

    def to_dict(self):
        return {
            'id': self.id,
            'org_id': self.org_id,
            'type': self.type,
            'name': self.name,
            'status': self.status,
            'config': self.get_config(),
            'last_verified_at': self.last_verified_at.isoformat() if self.last_verified_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

